<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users008_model extends CI_Model {

	public function create()
	{
		$data = array (
			'username_008' => $this->input->post('username_008'),
			'usertype_008' => $this->input->post('usertype_008'),
			'fullname_008' => $this->input->post('fullname_008'),
			'password_008' => password_hash($this->input->post('usertype_008'), PASSWORD_DEFAULT)
		);
		$this->db->insert('users008', $data);
	}

	public function read()
	{
		$query=$this->db->get('users008');
		return $query->result();
	}

	public function read_by($userid)
	{
		$this->db->where('userid_008', $userid);
		$query=$this->db->get('users008');
		return $query->row();
	}

	public function update($userid)
	{
		$data = array (
			'username_008' => $this->input->post('username_008'),
			'usertype_008' => $this->input->post('usertype_008'),
			'fullname_008' => $this->input->post('fullname_008'),
			'password_008' => password_hash($this->input->post('usertype_008'), PASSWORD_DEFAULT)
				
		);
		$this->db->where('userid_008', $userid);
		$this->db->update('users008', $data);
	}

	public function delete($userid)
	{
		$this->db->where('userid_008', $userid);
		$this->db->delete('users008');
	}

	public function reset($usertype)
	{
		$this->db->set('password_008',password_hash ($usertype,PASSWORD_DEFAULT));
		$this->db->where('usertype_008', $usertype);
		return $this->db->update('users008');
	}

}
