<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cats008_model extends CI_Model {

	public function create()
	{
		$data = array(
            'name_008'    => $this->input->post('name_008'),
            'type_008'    => $this->input->post('type_008'),
            'gender_008'  => $this->input->post('gender_008'),
            'age_008'     => $this->input->post('age_008'),
            'price_008'   => $this->input->post('price_008')
        );
        $this->db->insert('cats008',$data);
	}

    public function read($limit,$start)
    {
        $this->db->limit($limit,$start);
        $query=$this->db->get('cats008');
        return $query->result();
    }

    public function read_by($id)
    {
        $this->db->where('id_008',$id);
        $query=$this->db->get('cats008');
        return $query->row();
    }

    public function update($id)
    {
        $data = array(
            'name_008'    => $this->input->post('name_008'),
            'type_008'    => $this->input->post('type_008'),
            'gender_008'  => $this->input->post('gender_008'),
            'age_008'     => $this->input->post('age_008'),
            'price_008'   => $this->input->post('price_008')
        );
        $this->db->where('id_008',$id);
        $this->db->update('cats008',$data);   
    }

    public function delete($id)
    {
        $this->db->where('id_008',$id);
        $this->db->delete('cats008');
    }

    public function validation()
    {
        $this->load->library('form_validation');

        $this->form_validation->set_rules('name_008','Cat name','required');
        $this->form_validation->set_rules('type_008','Cat type','required');
        $this->form_validation->set_rules('gender_008','Cat gender','required');
        $this->form_validation->set_rules('age_008','Cat age','required');
        $this->form_validation->set_rules('price_008','Cat price','required');

        if($this->form_validation->run())
            return TRUE;
        else 
            return FALSE;
    }

    public function sale($id)
    {
        $data = array(
            'customer_name_008'       => $this->input->post('customer_name_008'),
            'customer_address_008'    => $this->input->post('customer_address_008'),
            'customer_phone_008'      => $this->input->post('customer_phone_008'),
            'cat_id_008'              => $id
        );
        $this->db->insert('catsales008',$data);
        $this->db->set('sold_008','1');
        $this->db->where('id_008',$id);
        $this->db->update('cats008' ); 
    }

    public function sales()
    {
        $query=$this->db->get('catsales008');
        return $query->result();
    }

    public function changephoto($id,$photo)
    {
        $this->db->where('id_008',$id);
        $query=$this->db->get('cats008');

        // if($this->session->userdata('photo') !== 'default.png')
        //     unlink('./uploads/users/'.$this->session->userdata('photo'));

        // $this->db->set('photo_008',$photo);
        // $this->db->where('username_008',$this->session->userdata('username'));
        // return $this->db->update('users008');
    }
}
