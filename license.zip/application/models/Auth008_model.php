<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth008_model extends CI_Model {

    public function getuser($username)
    {
        $this->db->where('username_008',$username);
        return $this->db->get('users008')->row();
    }

    public function changepass()
    {
        $this->db->set('password_008',password_hash($this->input->post('newpassword'), PASSWORD_DEFAULT));
        $this->db->where('username_008',$this->session->userdata('username'));
        return $this->db->update('users008');
    }

    public function changephoto($photo)
    {
        if($this->session->userdata('photo') !== 'default.png')
            unlink('./uploads/users/'.$this->session->userdata('photo'));

        $this->db->set('photo_008',$photo);
        $this->db->where('username_008',$this->session->userdata('username'));
        return $this->db->update('users008');
    }
}
