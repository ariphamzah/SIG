<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cats008 extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        if(! $this->session->userdata('username')) redirect('auth008/login');
        $this->load->model('Cats008_model');
        $this->load->model('Categories008_model');
    }

	public function index()
	{
        $this->load->library('pagination');

        $config['base_url']    = site_url('cats008/index');
        $config['total_rows']  = $this->db->count_all('cats008');
        $config['per_page']    = 5;

        $this->pagination->initialize ($config);

        $limit=$config['per_page'];
        $start=$this->uri->segment(3)?$this->uri->segment(3):0;

        $data['i']=$start+1;
        $data['cats']=$this->Cats008_model->read($limit,$start);
		$this->load->view('cats/cat_list_008',$data);
	}

    public function add()
    {
        if($this->input->post('submit')){
            $this->Cats008_model->create();
            if($this->db->affected_rows() > 0){
                $this->session->set_flashdata('msg','Added Cat Successfully...');
            } else {
                $this->session->set_flashdata('msg','Added Cat Failed !!!');
            }
            redirect('cats008');
        }
        $data['category']=$this->Categories008_model->read();
        $this->load->view('cats/cat_form_008',$data);
    }

    public function edit($id)
    {
        if($this->input->post('submit')){
            $this->Cats008_model->update($id);
            if($this->db->affected_rows() > 0){
                $this->session->set_flashdata('msg','Update Cat Successfully...');
            } else {
                $this->session->set_flashdata('msg','Update Cat Failed !!!');
            }
            redirect('cats008');
        }

        $data['category']=$this->Categories008_model->read();
        $data['cat']=$this->Cats008_model->read_by($id);
        $this->load->view('cats/cat_form_008',$data);   
    }

    public function delete($id)
    {
        $this->Cats008_model->delete($id);
        if($this->db->affected_rows() > 0){
            $this->session->set_flashdata('msg','Delete Cat Successfully...');
        } else {
            $this->session->set_flashdata('msg','Delete Cat Failed !!!');
        }
        redirect('cats008');
    }

    public function sale($id)
    {
        if($this->input->post('submit')){
            $this->Cats008_model->sale($id);
            if($this->db->affected_rows() > 0){
                $this->session->set_flashdata('msg','Sale Cat Successfully...');
            } else {
                $this->session->set_flashdata('msg','Sale Cat Failed !!!');
            }
            redirect('cats008');
        } 
        $data['cat']=$this->Cats008_model->read_by($id);
        $this->load->view('cats/cat_sale_008',$data); 
    }

    public function sales()
	{
        if($this->session->userdata('usertype') !='Manager') redirect('welcome');
        $data['sales']=$this->Cats008_model->sales();
		$this->load->view('cats/sale_list_008',$data);
	}

    public function changephoto($id)
    {
        if($this->input->post('upload')){
            if($this->upload()){
                $this->Cats008_model->changephoto($this->upload->data('file_name'));
                $this->session->set_userdata('photo',$this->upload->data('file_name'));
                $this->session->set_flashdata('msg','<p style="color:green;">Photo Successfuly Changed ...</p>');
            }
            else $data['error'] = $this->upload->display_errors();
        }
        $this->load->view('cats008/cat_photo_008',$data);
    }
}
