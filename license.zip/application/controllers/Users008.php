<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users008 extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if(! $this->session->userdata('username')) redirect('auth008/login');
		$this->load->model('users008_model');
	}

	public function index()
	{
		$data['users']=$this->users008_model->read();
		$this->load->view('users008/user_list_008', $data);
	}

	public function add()
	{
		if ($this->input->post('submit')) {
			$this->users008_model->create();
			if ($this->db->affected_rows() > 0) {
				$this->session->set_flashdata('msg','<div class="alert alert-success"><strong>Add Successfully!</strong></div>');
			} else {
				$this->session->set_flashdata('msg','<div class="alert alert-danger"><strong>Add Failed!</strong></div>');
			}
			redirect('users008');
		}
		

		$this->load->view('users008/user_form_008');
	}

	public function edit($userid) 
	{
		if ($this->input->post('submit')) {
			$this->users008_model->update($userid);
			if ($this->db->affected_rows() > 0) {
				$this->session->set_flashdata('msg','<div class="alert alert-success"><strong>Update Successfully!</strong></div>');
			} else {
				$this->session->set_flashdata('msg','<div class="alert alert-danger"><strong>Update Failed!</strong></div>');
			}
			redirect('users008');
		}

		$data['user']=$this->users008_model->read_by($userid);
		$this->load->view('users008/user_form_008', $data);
	}

	public function delete($userid)
	{
		$this->users008_model->delete($userid);
		if ($this->db->affected_rows() > 0) {
				$this->session->set_flashdata('msg','<div class="alert alert-success"><strong>Delete Successfully!</strong></div>');
			} else {
				$this->session->set_flashdata('msg','<div class="alert alert-danger"><strong>Delete Failed!</strong></div>');
			}
		redirect('users008');
	}

	public function reset($userid)
	{
		$this->users008_model->reset($userid);
		if ($this->db->affected_rows() > 0) {
				$this->session->set_flashdata('msg','<div class="alert alert-success"><strong>Reset Password Successfully!</strong></div>');
			} else {
				$this->session->set_flashdata('msg','<div class="alert alert-danger"><strong>Reset Password Failed!</strong></div>');
			}
		redirect('users008');
	}
}
