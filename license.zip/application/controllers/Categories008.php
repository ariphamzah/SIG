<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Categories008 extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        if(! $this->session->userdata('username')) redirect('auth008/login');
        $this->load->model('Categories008_model');
    }

	public function index()
	{
        $data['desc']=$this->Categories008_model->read();
		$this->load->view('categories/categories_list_008',$data);
	}

    public function add()
    {
        if($this->input->post('submit')){
            $this->Categories008_model->create();
            if($this->db->affected_rows() > 0){
                $this->session->set_flashdata('msg','Added Categories Successfully...');
            } else {
                $this->session->set_flashdata('msg','Added Categories Failed !!!');
            }
            redirect('categories008');
        }
        
        $this->load->view('categories/categories_form_008');
    }

    public function edit($id)
    {
        if($this->input->post('submit')){
            $this->Categories008_model->update($id);
            if($this->db->affected_rows() > 0){
                $this->session->set_flashdata('msg','Update Categories Successfully...');
            } else {
                $this->session->set_flashdata('msg','Update Categories Failed !!!');
            }
            redirect('categories008');
        }

        $data['des']=$this->Categories008_model->read_by($id);
        $this->load->view('categories/categories_form_008',$data);   
    }

    public function delete($id)
    {
        $this->Categories008_model->delete($id);
        if($this->db->affected_rows() > 0){
            $this->session->set_flashdata('msg','Delete Categories Successfully...');
        } else {
            $this->session->set_flashdata('msg','Delete Categories Failed !!!');
        }
        redirect('categories008');
    }
}
