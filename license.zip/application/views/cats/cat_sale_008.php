<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CATSHOP 008</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <?php $this->load->view('templates/header'); ?>
    <div class="m-4">
        <h1 class="mb-4">CATSHOP 008</h1>
        <h3 class="">CATS SALE FORM</h3>
        <hr>
        
        <form method="post" action ="">
            <table>
                <tr>
                    <td><label>Cat Id </label></td>
                    <td><label>: <?=$cat->id_008?></label></td>
                </tr>
                <tr>
                    <td><label>Cat Name </label></td>
                    <td><label>: <?=$cat->name_008?></label></td>
                </tr>
                <tr>
                    <td><label>Cat Type </label></td>
                    <td><label>: <?=$cat->type_008?></label></td>
                </tr>
                <tr>
                    <td><label>Cat Price &emsp;</label></td>
                    <td><label>: $ <?=$cat->price_008?></label></td>
                </tr>
            </table>
                <div class="mt-5 mb-3 w-25">
                    <label for="exampleFormControlInput1" class="form-label">Customer Name</label>
                    <input type="text" class="form-control" name="customer_name_008"  value="" required>
                </div>
                <div class="mb-3 w-25">
                    <label for="exampleFormControlTextarea1" class="form-label">Customer Address</label>
                    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="customer_address_008"></textarea>
                </div>
                <div class="mb-3 w-25">
                    <label for="exampleFormControlInput1" class="form-label">Customer Phone</label>
                    <input type="text" class="form-control" name="customer_phone_008"  value="" required>
                </div>
                <input class="btn btn-success" type="submit" value="Submit" name="submit">
                <input class="btn btn-primary" type="reset" value="Reset">
        </form>
        <a class="ms-0 mt-5  btn btn-warning" href="<?=site_url('cats008/index')?>">Back</a>
    </div>
    <?php $this->load->view('templates/footer'); ?>
</body>
</html>