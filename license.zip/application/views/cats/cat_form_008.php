<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CATSHOP 008</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <?php $this->load->view('templates/header'); ?>
    <div class="m-4">
        <h1 class="mb-4">CATSHOP 008</h1>
        <h3 class="">CATS FORM</h3>
        <hr>
        <?php
        $name     ='';
        $type     ='';
        $gender   ='';
        $age      ='';
        $price    ='';

        if(isset($cat)){
            $name     =$cat->name_008;
            $type     =$cat->type_008;
            $gender   =$cat->gender_008;
            $age      =$cat->age_008;
            $price    =$cat->price_008;
        }
        ?>
        <form method="post" action =""> 
                <div class="mb-3 w-25">
                    <label for="exampleFormControlInput1" class="form-label">Name</label>
                    <input type="text" class="form-control" name="name_008"  value="<?=$name?>" required>
                </div>
                <div class="w-25 mb-3">
                <label for="exampleFormControlInput1" class="form-label">Type</label>
                    <select class="form-select" aria-label="Default select example" name="type_008" required>
                        <option value="">Choose Type</option>
                        <?php foreach($category as $cate){ ?>
                            <option value="<?=$cate->cate_name_008?>" <?=set_select('type_008',$cate->cate_name_008,$type==$cate->cate_name_008?TRUE:FALSE)?>><?=$cate->cate_name_008?></option>
                        <?php } ?>
                    
                        </select>
                </div>
                <div>
                    <label for="exampleFormControlInput1" class="form-label">Gender</label>
                    <div class="form-check">
                        <input class="form-check-input ms-3" type="radio" id="flexRadioDefault1" value="Male" name="gender_008" required <?=$gender=='Male'?'checked':''?>>
                        <label class="form-check-label" for="flexRadioDefault1">
                            Male
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input ms-3" type="radio" id="flexRadioDefault2" value="Female" name="gender_008" required <?=$gender=='Female'?'checked':''?>>
                        <label class="form-check-label" for="flexRadioDefault2">
                            Female
                        </label>
                    </div>
                </div>
                <div class="mb-3 w-25">
                    <label for="exampleFormControlInput1" class="form-label">Age (month)</label>
                    <input type="number" class="form-control" name="age_008" value="<?=$age?>" required>
                </div>
                <div class="mb-3 w-25">
                    <label for="exampleFormControlInput1" class="form-label">Price ($)</label>
                    <input type="number" class="form-control" name="price_008" value="<?=$price?>" required>
                </div>
                <input class="btn btn-success" type="submit" value="Submit" name="submit">
                <input class="btn btn-primary" type="reset" value="Reset">
        </form>
        <a class="ms-0 mt-5  btn btn-warning" href="<?=site_url('cats008/index')?>">Back</a>
    </div>
    <?php $this->load->view('templates/footer'); ?>
</body>
</html>