<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CATSHOP 008</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <?php $this->load->view('templates/header'); ?>
    
    <h1 class="m-4">CATSHOP 008</h1>
    <h3 class="m-4">CATS LIST</h3>
    <div class="mt-4 ms-4">
        <p class="font-weight-light text-info"><?=$this->session->flashdata('msg')?></p>
    </div>
    <br>
    <a class="mt-1 ms-4 btn btn-warning" href="<?=site_url('cats008/add')?>">Add New Cat</a>
    <table class="table table-bordered m-5 w-75">
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Type</th>   
            <th>Gender</th>
            <th>Age (month)</th>            
            <th>Price ($)</th>
            <th>Photo</th>
            <th colspan="3" class="text-center">Action</th>
        </tr>   
        <?php foreach($cats as $cat){ ?>
        <tr>
            <td><?=$i++?></td>
            <td><?=$cat->name_008?></td>
            <td><?=$cat->type_008?></td>
            <td><?=$cat->gender_008?></td>
            <td><?=$cat->age_008?></td>
            <td><?=$cat->price_008?></td>
            <td>
                <center>
                    <img src="<?=base_url('uploads/cats/'.$cat->photo_008)?>" class="rounded" style='width:70px;' alt="..."><br>
                    <a href="<?=site_url('cats008/changephoto/'.$cat->id_008)?>" class="btn btn-outline-success m-2">Change Photo</a>
                </center>
            </td>
            <td class="text-center"><a href="<?=site_url('cats008/edit/'.$cat->id_008)?>" class="btn btn-primary">Edit</a></td>
            <td class="text-center"><a href="<?=site_url('cats008/delete/'.$cat->id_008)?>" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</a></td>
            <td class="text-center"><?php if($cat->sold_008==1) echo 'SOLD'; else { ?><a href="<?=site_url('cats008/sale/'.$cat->id_008)?>" class="btn btn-warning">Sale</a></td><?php } ?>
        </tr> <?php } ?>
    </table>

    <!-- <nav aria-label="Page navigation example">
        <ul class="pagination">
            <li class="page-item">
            <a class="page-link" href="#" aria-label="Previous">
                <span aria-hidden="true">&laquo;</span>
            </a>
            </li>
            <li class="page-item"><a class="page-link" href="#">1</a></li>
            <li class="page-item"><a class="page-link" href="#">2</a></li>
            <li class="page-item"><a class="page-link" href="#">3</a></li>
            <li class="page-item">
            <a class="page-link" href="#" aria-label="Next">
                <span aria-hidden="true">&raquo;</span>
            </a>
            </li>
        </ul>
    </nav> -->

    <center>
        <p class="badge bg-warning text-dark" style="width: 6rem;"><?=$this->pagination->create_links();?></p>
    </center>
    <?php $this->load->view('templates/footer'); ?>
</body>
</html>