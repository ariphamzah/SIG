<!DOCTYPE html>
<html>
<head>
    <title>Stock Op Name</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    
    <?php $this->load->view('templates/header'); ?>
    
    <div class="container_login">
        <center>
            <h3 class="mb-3" style="margin-top:50px" >Change Photo</h3><br>

            <?=$this->session->flashdata('msg')?>
            <div style="color:red;"><?=$error?></div>

            <form method="POST" action="" enctype="multipart/form-data">
                <label for="formFile" class="form-label">Current Photo</label>
            <div class="text-center">
                <img src="<?=base_url('uploads/users/'.$this->session->userdata('photo'))?>" class="rounded" style='width:200px; margin-bottom:20px;' alt="...">            
            </div>
            <div class="mb-3">
                <label for="formFile" class="form-label">New Photo</label>
                <input class="form-control w-25" type="file" name="photo" id="formFile" required>
            </div>
        <center>

        </center>
                <input class="btn btn-primary mt-3" type="submit" name="upload" value="UPLOAD PHOTO"/>
            </form>
        </center>
    </div>

    <a class="ms-5 mt-5  btn btn-warning"  href="<?=site_url('cats008/index')?>">Back to Home</a>

    <?php $this->load->view('templates/footer'); ?>
</body>
</html>