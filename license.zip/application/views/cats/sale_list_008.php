<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CATSHOP 008</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <?php $this->load->view('templates/header'); ?>
    
    <h1 class="m-4">CATSHOP 008</h1>
    <h3 class="m-4">CATS LIST</h3>
    <div class="mt-4 ms-4">
        <p class="font-weight-light text-info"><?=$this->session->flashdata('msg')?></p>
    </div>
    <br>
    <a class="m-4 btn btn-warning" href="<?=site_url('cats008/add')?>">Add New Cat</a>
    <hr>
    <table class="table table-bordered m-5 w-75">
        <tr>
            <th>No</th>
            <th>Sale ID</th>
            <th>Sale Date</th>   
            <th>Cat ID</th>
            <th>Customer Name</th>
            <th>Customer Address</th>
            <th>Customer Phone</th>
        </tr>   
        <?php $i=1; foreach($sales as $sale){ ?>
        <tr>
            <td><?=$i++?></td>
            <td><?=$sale->sale_id_008?></td>
            <td><?=$sale->sale_date_008?></td>
            <td><?=$sale->cat_id_008?></td>
            <td><?=$sale->customer_name_008?></td>
            <td><?=$sale->customer_address_008?></td>
            <td><?=$sale->customer_phone_008?></td>
        </tr> <?php } ?>
    </table>
    <?php $this->load->view('templates/footer'); ?>
</body>
</html>