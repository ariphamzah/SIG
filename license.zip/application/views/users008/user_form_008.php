<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CATSHOP 008</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <?php $this->load->view('templates/header'); ?>
    <div class="m-4">
        <h1 class="mb-4">CATSHOP 008</h1>
        <h3 class="">USER FORM</h3>
        <hr>
        <?php
        $username     ='';
        $usertype     ='';
        $fullname     ='';

        if(isset($user)){
            $username     =$user->username_008;
            $usertype     =$user->usertype_008;
            $fullname     =$user->fullname_008;
        }
        ?>
        <form method="post" action ="">
                <div class="mb-3 w-25">
                    <label for="exampleFormControlInput1" class="form-label">Username</label>
                    <input type="text" class="form-control" name="username_008"  value="<?=$username?>" required>
                </div>
                <div class="w-25 mb-3">
                    <label for="exampleFormControlInput1" class="form-label">Usertype</label>
                    <select class="form-select" aria-label="Default select example" name="usertype_008" required>
                        <option value="">Choose</option>
                        <option value="Manager" <?=$usertype=='Manager'?'selected':'';?> >Manager</option>
                        <option value="Cashier" <?=$usertype=='Cashier'?'selected':'';?> >Cashier</option>
                    </select>
                </div>
                <div class="mb-3 w-25">
                    <label for="exampleFormControlInput1" class="form-label">Fullname</label>
                    <input type="text" class="form-control" name="fullname_008"  value="<?=$fullname?>" required>
                </div>
                <input class="btn btn-success" type="submit" value="Submit" name="submit">
                <input class="btn btn-primary" type="reset" value="Reset">
        </form>
        <a class="ms-0 mt-5  btn btn-warning" href="<?=site_url('users008/index')?>">Back</a>
    </div>
    <?php $this->load->view('templates/footer'); ?>
</body>
</html>