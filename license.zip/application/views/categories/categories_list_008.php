<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CATSHOP 008</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <?php $this->load->view('templates/header'); ?>
    
    <h1 class="m-4">CATSHOP 008</h1>
    <h3 class="m-4">CATEGORIES LIST</h3>
    <a class="m-4 btn btn-warning" href="<?=site_url('Categories008/add')?>">Add New Categories</a>
    <hr>
    <table class="table table-bordered m-5 w-75">
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Description</th>
            <th class="text-center" colspan="2">Action</th>
        </tr>   
        <?php $i=1; foreach($desc as $des){ ?>
        <tr>
            <td><?=$i++?></td>
            <td><?=$des->cate_name_008?></td>
            <td><?=$des->description_008?></td>
            <td class="text-center"><a href="<?=site_url('categories008/edit/'.$des->cate_id_008)?>" class="btn btn-primary">Edit</a></td>
            <td class="text-center"><a href="<?=site_url('categories008/delete/'.$des->cate_id_008)?>" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</a></td>
        </tr> <?php } ?>
    </table>
    <?php $this->load->view('templates/footer'); ?>
</body>
</html>