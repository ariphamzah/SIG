<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CATSHOP 008</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <?php $this->load->view('templates/header'); ?>
    <div class="m-4">
        <h1 class="mb-4">CATSHOP 008</h1>
        <h3 class="">CATEGORIES FORM</h3>
        <hr>
        <?php
        $name     ='';
        $desc     ='';

        if(isset($des)){
            $name     =$des->cate_name_008;
            $desc     =$des->description_008;
        }
        ?>
        <form method="post" action ="">
                <div class="mb-3 w-25">
                    <label for="exampleFormControlInput1" class="form-label">Name</label>
                    <input type="text" class="form-control" name="cate_name_008"  value="<?=$name?>" required>
                </div>
                <div class="mb-3 w-25">
                    <label for="exampleFormControlInput1" class="form-label">Description</label>
                    <textarea name="description_008" id="" cols="30" rows="10" required><?=$desc?></textarea>
                </div>
                <input class="btn btn-success" type="submit" value="Submit" name="submit">
                <input class="btn btn-primary" type="reset" value="Reset">
        </form>
        <a class="ms-0 mt-5  btn btn-warning" href="<?=site_url('categories008/index')?>">Back</a>
    </div>
    <?php $this->load->view('templates/footer'); ?>
</body>
</html>