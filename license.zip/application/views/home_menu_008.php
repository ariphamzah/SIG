<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CATSHOP 008</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <?php $this->load->view('templates/header'); ?>
    
    <div class="mt-4 ms-4">
        <p class="font-weight-light text-info"><?=$this->session->flashdata('msg')?></p>
        
        <h1 class="text-center" style="margin-bottom:28px; margin-top:100px;">CATSHOP ARIP</h1>
        <h3 class="text-center" style="margin-bottom:28px; margin-top:28px;">WELLCOME <?=$this->session->userdata('fullname')?>, you are login as <?=$this->session->userdata('usertype')?></h3>
        <div class="text-center">
            <img src="<?=base_url('uploads/users/'.$this->session->userdata('photo'))?>" class="rounded" style='width:200px; margin-bottom:20px;' alt="...">            
        </div>
        <center><a class="btn btn-outline-primary" href="<?=site_url('auth008/changephoto')?>">Change Photo</a></center>

    </div>
    <br>
    
    <?php $this->load->view('templates/footer'); ?>
</body>
</html>