<!DOCTYPE html>
<html>
<head>
    <title>Stock Op Name</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    
    <?php $this->load->view('templates/header'); ?>
    
    <div class="container_login">
        <center>
            <h3 class="mb-3" style="margin-top:160px" >Change Password</h3><br>

            <?=$this->session->flashdata('msg')?>

            <form method="POST" action="">
                <div class="mb-3 w-25 ">
                    <input type="password" class="form-control"name="oldpassword" placeholder="Old Username" required>
                </div>  
                <div class="mb-3 w-25">
                    <input type="password" class="form-control" name="newpassword" id="pass" placeholder="New Password" required>
                </div>
        <center>
                <input type="checkbox" onclick="show()"> Show Password
        </center>
                <input class="btn btn-primary mt-3" style="margin-bottom:17px" type="submit" name="change" value="CHANGE PASSWORD"/>
            </form>
        </center>
    </div>

    <a class="ms-5 mt-5  btn btn-warning"  href="<?=site_url('welcome')?>">Back to Home</a>

    <?php $this->load->view('templates/footer'); ?>

    <script>
        function show(){
            var x = document.getElementById("pass");
            if (x.type === "password"){
                x.type = "text";
            }
            else {
                x.type = "password";
            }
        }
    </script>
</body>
</html>