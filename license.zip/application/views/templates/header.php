<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-info">
  <div class="container-fluid">
    <h4 class="text-center ps-2 pe-3 mb-lg-0">APPS MENU</h4>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="<?=site_url('welcome')?>">Home</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" href="<?=site_url('cats008')?>">Manage Cats</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?=site_url('categories008')?>">Manage Categories</a>
        </li>

        <?php if ($this->session->userdata('usertype')=='Manager'){?>
        <li class="nav-item">
          <a class="nav-link" href="<?=site_url('users008')?>">Manage User</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?=site_url('cats008/sales')?>">Sales Report</a>
        </li>
        <?php } ?>
        <li class="nav-item">
          <a class="nav-link" href="<?=site_url('auth008/changepass')?>">Change Password</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?=site_url('auth008/logout')?>">Logout</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
</body>
</html>
